import { User } from './user';

export const UserMock: User[] = [
    new User(1, 'joao','joao@joao', 33, 'photos')
];
